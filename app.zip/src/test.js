<div className="menu">
<img id="img" src='https://www.microsoft.com/en-us/research/uploads/prod/2020/05/FrontiersInMachineLearning_MCRWebHeader_1920x720-3-scaled.jpg'></img> 
<h1 id="name">Name Project : </h1>
<p id="Text">
   Mobile robot controlling by using
   <br></br>
     machine learning <strong><mark style={{color:'red',background:'white'}}>(Tensorflow.js)</mark>.</strong>
</p>
<br/>
<br/>
<h3 id="aboutH">About the project: </h3>
<p id="aboutP">Take dimensions of face and analyze 
<br/>
it by algorithm <strong><mark style={{color:'red',background:'white'}}>(MTCNN)</mark></strong> then he
<br/>
moves mobile robot according to
<br/> 
the movement of the face.</p>
<Link to="/Mleraning">
<button id="btn">Go to the Project</button>
</Link>

<h4><strong style={{color:'maroon'}}>Created by</strong> Yahya Mohand <SocialIcon url="https://www.linkedin.com/in/yahya-mohnd-04b0821b0/"/></h4> 

</div>












//       <div className="container">
//           <div className="container__half">
//           <img id='img' src={logo}></img>
//           <h1 id="name">Name Project : </h1>
//       <p id="Text">
//         Mobile robot controlling by using
//         <br></br>
//           Deep learning <strong><mark style={{color:'red',background:'white'}}>(Tensorflow.js)</mark>.</strong>
//       </p>
//       <br/>

//       <br/>
//       <h3 id="aboutH">About the project: </h3>
//       <p id="aboutP">Take face gesture recognition  
//       <br/>
//       and analyze then he
//       <br/>
//       <Link to="/Mleraning">
//       <button className="button button1">Go to the Project</button>
//     </Link>
//       moves mobile robot according to
//       <br/> 
//       the movement of the face.</p>

     
//  </div>

//     <div className="container__half">
//       <p id="Text">
//        Hello World
//        <br></br>
//         I`m Yahya Al-Kirikji 
//       </p>
//     </div>
// </div>